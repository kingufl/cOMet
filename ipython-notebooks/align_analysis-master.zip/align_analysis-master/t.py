import re
for line in open("debug4"):
    mobj = re.search(r"Aligned at optical frag (\d+)\(sa (\d+)\)\. Locus (\d+)\(sa (\d+)\)", line)
    if mobj: print mobj.groups()
