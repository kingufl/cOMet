

import Bio




import math
import re
from Bio import SearchIO
from Bio import SeqIO
import Bio.Restriction
import Bio.SearchIO
import itertools
#import utils
import random
import subprocess 
import sys
import struct
import locale
import ormutils
import collections
import functools
import ormutils
import itertools

from IPython.parallel import depend
locale.setlocale(locale.LC_ALL, 'en_US')

import ormutils
import imp
imp.reload(ormutils)

spades_rr_cfg = ormutils.ConfigSet("spades_rr", "tularensis",
                                   "/s/chopin/h/proj/soma/data/tularensis/cluster/spades_assembly/cmdlinescratch/",
            "/s/chopin/h/proj/soma/data/tularensis/cluster/",
            "reference/tularensis", 
             "spades_assembly/contigs.fasta",
             "spades_assembly/quast_ma_rr.txt",
             "spades_assembly/quast_local_ma_rr.txt",
             "spades_assembly/sequel_ma_rr.txt",
             700, 150, True)

abyss_p_cfg = ormutils.ConfigSet("abyss","pine",
                               "/s/chopin/h/proj/soma/data/pine/abyss_assembly/scratch/",
            "/s/chopin/h/proj/soma/data/pine/",
            "reference.fasta", 
             "abyss_assembly/processed_contig.fa",
             "abyss_assembly/quast_ma.txt",
             "abyss_assembly/quast_local_ma.txt",
             "abyss_assembly/sequel_ma.txt",
            700, 150, True)
n=0
enzymes = set(('SmiI', 'CjeNII', 'Pfl1108I'))
enzymes = set(('TssI', 'Esp3I', 'PciSI'))
def get_alignments(argtuple):
    import sys
    sys.path.append('/s/chopin/h/proj/soma/data/ecoli')
    import ormutils
    import Bio.Restriction
    import imp
    imp.reload(ormutils)

    
    cfg_set_a, enzyme_name, runnum = argtuple

    
    
    cfg_set = ormutils.ConfigSet(*cfg_set_a)
    ormutils.make_optmap(enzyme_name, cfg_set.srcdir + cfg_set.ref_genome, 
                         cfg_set.dstdir + "enz_" + enzyme_name + ".om.bin", 
                         Bio.Restriction.AllEnzymes,  
                         cfg_set.small_cutoff, cfg_set.stddev,
                         is_circular=cfg_set.is_circular)
    ormutils.run_digest(enzyme_name, 
                        cfg_set.srcdir + cfg_set.assembly, 
                        cfg_set.dstdir)
    return ormutils.run_twin(enzyme_name, cfg_set.dstdir)
all_cfgs = [abyss_p_cfg]#[spades_rr_cfg]
#all_cfgs = [spades_rr_cfg]
runnums = range(1)
all_cfgs_enzymes = [(tuple(cfg), enz_name,runnum) for cfg, enz_name,runnum in itertools.product(all_cfgs, enzymes, runnums)]
            
all_cfgs_enzymes_results = map(get_alignments, all_cfgs_enzymes)


def cfg_from_name(lst, name):
    for cfg in lst: 
        if cfg.name == name: return cfg

import random
import operator
import time
def take(n, iterable):
    "Return first n items of the iterable as a list"
    return list(itertools.islice(iterable, n))

good_enzymes = {}

all_good_enzymes = enzymes

asmaligns = {}
for twinrun, (cfg, enz_name) in zip(all_cfgs_enzymes_results, itertools.product(all_cfgs, enzymes)):
    if not cfg.name in asmaligns: asmaligns[cfg.name] = {}
    for contig in twinrun:
        if enz_name not in asmaligns[cfg.name]: asmaligns[cfg.name][enz_name] ={}
        asmaligns[cfg.name][enz_name][contig] = twinrun[contig]
        n += 1
    #asmaligns[cfg.name][enz_name] = twinrun
print(n/len(enzymes), "alignments per enzymes")


def fix_contigs1(sequel_contigs):
    
    new_mis_contigs = set()
    for miscontig in sequel_contigs:
        new_mis_contigs.add("contig-50_" + miscontig.split("_")[1])
    return new_mis_contigs

def fix_contigs2(mis_contigs):
    new_mis_contigs = set()
    for miscontig in mis_contigs:
        fields = miscontig.split("_")
        if fields[0] == "contig-50":
            new_mis_contigs.add("_".join(fields[:2]))
        else:
            new_mis_contigs.add(fields[0])
    return new_mis_contigs

def run_classifiers():

    for asmnum, asm in enumerate(  asmaligns):
        start = time.time()
        good_enzymes[asm] = set()
        print("***************************")
        print("Assembly",asmnum,":",asm,"starting at",time.time() - start, "seconds")
        aligns = asmaligns[asm]
        cfg = cfg_from_name(all_cfgs, asm)
        print("Genome:", cfg.genome)
        allcontig_names = set([])
        contig_fasta_index = {}
        genome_size = 0
        all1s = 0
        for recnum, record in enumerate((record for record in SeqIO.parse(open( cfg.srcdir + cfg.assembly), "fasta") if len(record.seq) >= 500 )):
            allcontig_names.add(record.id)
            contig_fasta_index[record.id] = recnum
            all1s |= (1 << recnum)
            genome_size += len(record.seq)
        print("finished loading contigs at",time.time() - start, "seconds")
        with open(cfg.srcdir + cfg.quast_ma) as f:
            mas = set([line.strip()[1:] for line in f])
            mas.discard('')
        with open(cfg.srcdir + cfg.quast_local_ma) as f:
            local_mas = set([line.strip()[1:] for line in f])
            local_mas.discard('')


        with open(cfg.srcdir + cfg.sequel_ma) as f:
            sequel_contigs = set([line.strip()[1:] for line in f])

        # cuts
        cuts = {}
        contig_recs = [record for record in  Bio.SeqIO.parse(open(cfg.srcdir + cfg.assembly, "rU"), "fasta") if len(record.seq) > 500]
        print("digesting contigs at",time.time() - start, "seconds")
        for enum, enzyme in enumerate(all_good_enzymes):
            #print(len(contig_recs),"contigs, getting cut info for enzyme", enzyme,
            #      enum,"/",len(all_good_enzymes))
            #print("get cut info for contigs in",cfg.srcdir + cfg.assembly,
            #      "for enzyme", enzyme)

            cuts[enzyme] = ormutils.soft_digest_contigs(enzyme, contig_recs)
        print("finished digesting contigs at",time.time() - start, "seconds")
        mis_contigs = mas | local_mas
        print("misassemblies:", len(mis_contigs),"/",len(allcontig_names))
        print("correct assemblies:",len(allcontig_names) - len(mis_contigs))
        print("misassemblies not found in assembly:", mis_contigs - set(allcontig_names))
        print("sequel suspected misassemblies:", len(sequel_contigs))

        #hack to deal with idba sequel
        common = sequel_contigs & set(allcontig_names)
        if len(sequel_contigs) != len(common):
            print("fixing sequel misspelled contig names")
            sequel_contigs = fix_contigs1(sequel_contigs)
        common = sequel_contigs & set(allcontig_names) #recompute common now that we've fixed it

        print("sequel_contigs:", len(sequel_contigs), len(common))
        assert(len(sequel_contigs) == len(common))

        #hack to deal with soap assembly
        if len(mis_contigs - set(allcontig_names)) > 0:
            print("fixing quast misspelled contig names")
            mis_contigs = fix_contigs2(mis_contigs)
            local_mas = fix_contigs2(local_mas)
            mas = fix_contigs2(mas)
            
        print("corrected misassemblies not found in assembly:", mis_contigs - set(allcontig_names))
        assert(len(mis_contigs)==len(set(allcontig_names) & mis_contigs))
        enz_to_use = all_good_enzymes & set(cuts)

        print("Creating file-source bit vectors (i.e. quast and sequel) at", time.time() - start,"seconds")
        masbs = 0
        for ma in mas:
            masbs |=  ( 1 << contig_fasta_index[ma])
        local_masbs = 0
        for ma in local_mas:
            local_masbs |= ( 1 << contig_fasta_index[ma])

        sequel_contigsbs = 0

        for contig in sequel_contigs:
               sequel_contigsbs |= ( 1 << contig_fasta_index[contig])
        print("Computing enzyme bit vectors at", time.time() - start,"seconds")
        enzymebs = {}
        for enznum,e in enumerate(enz_to_use):
            #print(enznum,e)
            enzymebs[e] = 0
            # first mark the contigs we have alignments for or have an alibai like few cuts
            for contig in allcontig_names:
                e_cutsgood = contig in cuts[e] and len(cuts[e][contig]) >= 2 
                if not e_cutsgood: 
                    enzymebs[e] |= (1 << contig_fasta_index[contig]) # give it the benefit of the doubt
                else:
                    if e in aligns and contig in aligns[e]:
                        enzymebs[e] |= (1 << contig_fasta_index[contig])
            # then complement to get misassemblies marked
            enzymebs[e] = enzymebs[e] ^ all1s
                
        print("finished computing enzyme bit vectors at",time.time() - start, "seconds")
        print("exploring combinations of", len(enz_to_use), "enzymes")
        #for enz in aligns:
        combos = list(itertools.combinations(enz_to_use,3))
        random.shuffle(combos)
        for with_sequel, with_orm in itertools.product([False, True], [False,True]):
            if (with_sequel, with_orm) == (False, False): continue
            print("------ With sequel:", with_sequel, ", With ORM:", with_orm, "------")
            bestmcc = -1.0
            bestdist = math.sqrt(2)
            bestrates = 0.0

            for combonum, e_set in enumerate(combos):

                cfyer = all1s
                if with_orm:
                    cfyer &= functools.reduce(operator.or_, map(lambda e: enzymebs[e], e_set))
                if with_sequel: 
                    cfyer &= sequel_contigsbs
                
                    
                allmsbs = (masbs | local_masbs)
                #tp = bin( (all1s ^ cfy_neg) & allmsbs ).count("1")
                mas_tp = bin( cfyer & masbs ).count("1")
                local_mas_tp = bin( cfyer & local_masbs ).count("1")
                tp = mas_tp + local_mas_tp
                fp = bin(cfyer & (all1s ^ allmsbs) ).count("1")
                tn = bin((all1s ^ allmsbs) & (all1s ^ cfyer)).count("1")
                fn = bin( allmsbs & (all1s ^ cfyer)).count("1")

                tpr = tp/(tp+fn) # fraction of positive instances that were labeled as such
                fpr = fp/(fp+tn) # fraction of negatives that were mislabeled as positive

                try:
                    mcc = (tp*tn - fp*fn)/math.sqrt( (tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
                except ZeroDivisionError:
                    mcc = (tp*tn - fp*fn)/1.0
                dist = math.sqrt(fpr**2 + (1-tpr)**2)
                if dist < 0.707:
                        good_enzymes[asm].add( (dist,e_set))
                if mcc > bestmcc:
                    bestmcc = mcc
                    print("best mcc so far:",mcc,"mas_tp:",mas_tp,"local_mas_tp:",local_mas_tp,"fp:",fp,"tn:",tn,"fn:",fn,"tpr:",tpr,"fpr:",fpr,"enzyme:",e_set,
                          "combo num:", combonum)
                rates = min([tpr, 1.0-fpr])
                if  rates > bestrates:
                    bestrates = rates
                    print("best rates so far:",rates,"mas_tp:",mas_tp,"local_mas_tp:",local_mas_tp,"fp:",fp,"tn:",tn,"fn:",fn,"tpr:",tpr,"fpr:",fpr,"enzyme:",e_set, 
                          "combo num:", combonum)

                if dist < bestdist:
                    bestdist = dist
                    print("best dist so far:",dist,"mas_tp:",mas_tp,"local_mas_tp:",local_mas_tp,"fp:",fp,"tn:",tn,"fn:",fn,"tpr:",tpr,"fpr:",fpr,"enzyme:",e_set, 
                         "combo num:", combonum)
            print("Finished classifications at", time.time() - start,"seconds")

run_classifiers()
