#!/usr/bin/python3
import sys
import os
import optparse
import subprocess
import re
import multiprocessing
import collections
import Bio
import Bio.SeqIO
import Bio.Restriction

# Parse command line

opt_parser = optparse.OptionParser()
opt_parser.add_option("--reads1", action="store", dest="r1")
opt_parser.add_option("--reads2", action="store", dest="r2")
opt_parser.add_option("--contigs", action="store", dest="contigs")
opt_parser.add_option("--opt_map", action="append", dest="opt_map")
opt_parser.add_option("--outdir", action="store", dest="outdir")
opt_parser.add_option("--enzyme", action="append", dest="enzymes")
opt_parser.add_option("--is_prokaryote", action="store_true", dest="is_prokaryote")
opt_parser.add_option("--verbose", action="store_true", dest="verbose")
opts, args = opt_parser.parse_args()

# setup output directory

try:
    os.mkdir(opts.outdir)
except FileExistsError:
    print("ERROR: Output directory exists.")
    sys.exit(1)
    
#os.chdir(outdir)


# run prep
prep_cmd = " ".join(["missequel_prep.pl", "-r1", opts.r1, "-r2", opts.r2, "-c", opts.contigs, "-m", "-o", opts.outdir + "/prep"])
if opts.verbose: print("running: ", prep_cmd)
prep_subproc = subprocess.Popen(prep_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
prep_stdout, prep_stderr = prep_subproc.communicate()
if opts.verbose: print("prep output", prep_stdout, prep_stderr)


#prep_out = [print(line) for lin in prep_subproc.stdout]

insert_line_re = re.compile(r"Average external insert size: (\d+)")
with open(opts.outdir + "/prep/prep.log") as prep_log:
    for line in prep_log:
        match_obj = insert_line_re.search(line)
        if match_obj:
            insert_size = match_obj.group(1)


# run SEQuel
sequel_cmd = " ".join(["java", "-Xmx12g",  "main.ThreadManager", "-miss", "-A", opts.outdir + "/prep", "-i", insert_size , "-p", str(multiprocessing.cpu_count()), "-o", opts.outdir + "/posnl"])
if opts.verbose: print("running: ", sequel_cmd)
sequel_subproc = subprocess.Popen(sequel_cmd, shell=True)

sequel_stdout, sequel_stderr = sequel_subproc.communicate()
print("posnl missequel output: ", sequel_stdout, sequel_stderr)

# run TWIN
def silico_name(enzyme):
    return opts.outdir + "/" + "contigs_" + enzyme + ".silico"

def opt_map_name(enzyme):
    return opts.outdir + "/" + "opt_map_" + enzyme + ".bin"

Alignment = collections.namedtuple('Alignment', ['locus', 'fval', 'chi_square_sum', 'deviation_sum', 'num_matched_frags', 'chi_square_cdf', 'forward', 'max_dev', 'fragnum'])

def parse_twin(twin_stdout):
    localdict = {}
    matching_re = re.compile(r"^Matching contig ([^:]+):\(ignored (\d+)\) ((\d+ )+)\(ignored (\d+)\)")
    backward_re = re.compile(r"backward alignment:")
    alignment_pat_re = re.compile(r"Alignment pattern: ((\S+\t)+)")
    alignment_stats_re = re.compile(r"Alignment stats: (.*)")
    fin_string = "placed somewhere"
    found_end = False

    for line in twin_stdout:
        line = line.decode("utf-8")
        if line[:len(fin_string)] == fin_string: found_end = True

        mobj = alignment_stats_re.search(line)
        if mobj:
            astats = eval(mobj.group(1))
            astats['max_dev'] = 0
            astats['forward'] = forward
            a = Alignment(**astats)

            if astats['chi_square_cdf'] < .85:
                if not contig in localdict: localdict[contig]=[]
                localdict[contig].append(a)    

            continue

        mobj = matching_re.search(line)
        if mobj: 
            contig,leftignored,frags,_lastfrag,rightignored = mobj.groups()
            silicofrags = [int(part) for part in frags.split(" ")[0:-1]]
            forward = 0
            continue
        mobj = backward_re.search(line)
        if mobj:
            forward = 1
            continue

    

    if found_end:
        return localdict
    else:
        return {}

alignments = {}

for enzyme_num, enzyme in enumerate(opts.enzymes):
    # run digest (digest.py fasta_file enzyme_name out_fname)
    digest_subproc = subprocess.Popen(["digest.py", opts.contigs, enzyme, silico_name(enzyme)])
    digest_stdout, digest_stderr = digest_subproc.communicate()
    
    # convert to bytes
    # <SOMA format optical map> <output file> <bin size> [is_prokaryote]
    cmd = ["om2bytes.py", opts.opt_map[enzyme_num], opt_map_name(enzyme), "1"]
    if opts.is_prokaryote: cmd.append("True")
    if opts.verbose: print("running:", " ".join(cmd))
    om2bytes_subproc = subprocess.Popen(" ".join(cmd), shell=True)
    om2bytes_stdout, om2bytes_stderr = om2bytes_subproc.communicate()

    # run twin executable
    twin_cmd = ["twin", "--opt_map", opt_map_name(enzyme), #opts.opt_map[enzyme_num], # fixme 
                                     # use opt_map_name(enzyme),  and soma optical map format file instead
                                     "--silico", silico_name(enzyme), "--max_chisquare_cdf", "0.85", ]
    if opts.verbose: print("twin cmd:", " ".join(twin_cmd))
    twin_subproc = subprocess.Popen(" ".join(twin_cmd), shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    #twin_stdout, twin_stderr = twin_subproc.communicate()
    alignments[enzyme] = parse_twin(twin_subproc.stdout)
    if opts.verbose: print ("found", len(alignments[enzyme]), "contigs with alignments")

# load sequel contigs and fix names

def fix_contigs1(sequel_contigs):
    
    new_mis_contigs = set()
    for miscontig in sequel_contigs:
        new_mis_contigs.add("contig-50_" + miscontig.split("_")[1])
    return new_mis_contigs




allcontig_names = set([])

for recnum, record in enumerate((record for record in Bio.SeqIO.parse(open( opts.contigs), "fasta") if len(record.seq) >= 500 )):
    allcontig_names.add(record.id)

#fixme find SEQuel.output.14.11.06_1 type directory prefix
with open(opts.outdir + "/posnl/misassemblies.txt") as f:
    sequel_contigs = set([line.strip()[1:] for line in f])

common = sequel_contigs & set(allcontig_names)
if len(sequel_contigs) != len(common):
    print("fixing sequel misspelled contig names")
    sequel_contigs = fix_contigs1(sequel_contigs)
    common = sequel_contigs & set(allcontig_names) #recompute common now that we've fixed it
print("SEQuel reported", len(common), "misassembled contigs; refining with TWIN optical map alignments...")
# determine number of cuts per contig per enzyme so we can detect where there should be an ORM alignment but there isn't


def soft_digest_contigs(enzyme_name, contig_iterable):
    localdict = {}
    for record in contig_iterable:
        sites = [biosite - 1 for biosite in getattr(Bio.Restriction, enzyme_name).search(record.seq)]
        #sites = [m.start() + int(cut_offset) for m in re.finditer(recognition_sequence, str(record.seq))]
        localdict[record.id] = sites
    return localdict    

def soft_digest(enzyme_name, fasta_file):
    return soft_digest_contigs(enzyme_name, SeqIO.parse(open(fasta_file, "rU"), "fasta"))

cuts = {}
contig_recs = [record for record in  Bio.SeqIO.parse(open(opts.contigs, "rU"), "fasta") if len(record.seq) > 500]
for enum, enzyme in enumerate(opts.enzymes):
    cuts[enzyme] = soft_digest_contigs(enzyme, contig_recs)

def contig_misassembledp(contig_name):
    """Return True if both misSEQuel and TWIN results indicate a contig is misassembled."""
    # if SEQuel thinks it's okay, then it is
    if contig_name not in sequel_contigs: 
        print("SEQuel vindicated", contig_name)
        return False
    
    # otherwise it might be misassembled and we'll consule the ORM alignments

    # if any contig has enough cuts to be aligned, but has no alignments, consider it misassembled
    for enzyme_num, enzyme in enumerate(opts.enzymes):
        cuts_good = contig_name in cuts[enzyme] and len(cuts[enzyme][contig_name]) >= 2
        if cuts_good and contig_name not in alignments[enzyme]:
            print("ORM implicated", contig_name, "enzyme", enzyme_num, enzyme)
            return True
    print("no contradictory ORM data for", contig_name)
    return False
            
for contig_name in allcontig_names:
    if contig_misassembledp(contig_name):
        print("Misassembled:", contig_name)
