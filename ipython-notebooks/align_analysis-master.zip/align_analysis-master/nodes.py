import re,sys
for line in open("martins.psl"):
    if "match" in line: continue
    parts = re.split(r"\s+", line)
    
    
    if len(parts) > 17: 
        if int(parts[10]) >= 800 and int(parts[17]) == 1 and parts[8] == "+":
            print parts[9]

#        print parts[9], parts[5], parts[7]#, parts[17]
