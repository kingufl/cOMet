import pstats
p = pstats.Stats('cProfile.orig.out')
p.strip_dirs().sort_stats('time').print_stats()
