print "loading file..."
execfile("mldata2.py")
import numpy as np
import itertools
import random
from neuralnetworksMulti import *
import math
import PyML
from PyML.classifiers import multi

minp,maxp = 256,0

def prob_of_phred(phred):
    phred = phred - 33
    return 1.0 - 10**(phred*-.1)

def rephred(n):
    return n #-10 * math.log(n,10)

classmap = { 'A' : 1,
             'C' : 2,
             'G' : 3,
             'T' : 4 }

def feats_of_base(base, phred):
    phredprob = prob_of_phred(ord(phred))
    rest = rephred((1.0 - phredprob) / 3.0)
    feats = [ rest, rest, rest, rest]
    feats[classmap[base]-1] = rephred(phredprob)
    return feats


def feat_of_left_ovlp(o, r, p, readpos, actualread):
    nonovlp = len(r) - o
    if readpos < o:
        mappos = readpos+nonovlp - 0


        return feats_of_base(r[mappos], p[mappos])
    else:
        return [rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0)]

def norm_len(evr, evo):
    """given lists of read and other features, produce a list of length 10 with items permuted"""
    newlist = evr + evo
    if len( newlist) < 10:
        for i in range(10 - len(newlist)):
            newlist.append([rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0), 1.0])
    if len(newlist) > 10: 
        newlist = newlist[0:9]
    random.shuffle(newlist)
    #print newlist
#    print len(newlist)
    return newlist

def feats_of_right_ovlp(o,r,p,readpos,actualread):
    nonovlp = len(actualread) - o
    if readpos < nonovlp:
        return [rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0)]
    else:
        mappos = readpos - nonovlp 
        return feats_of_base(r[mappos], p[mappos])

print "generating features..."    
allfeats = []
alltargs = []
readcount = 0
already_correct =0
initially_wrong = 0
for ref,read,readphreds,lefts,rights in mldata:
    readcount +=1
    if readcount > 100: break
    T = []
    EVR = [] #evidence from read itself
    EVO = [] # evidence from others

    #print ref
    for i,base in enumerate(ref):
        T.append(classmap[base])
        if base == read[i]:
            already_correct += 1
        else:
            initially_wrong += 1
    #print read

    # create the positions for the features for each example
    for i in read:
        EVR.append([])
        EVO.append([])

    for readphred in readphreds:
        for pos, (r,p) in enumerate(itertools.izip(read, readphred)):
            EVR[pos].append( feats_of_base(r,p) + [1.0])
            
        #print "    ", readphred
        for c in readphred:
            if ord(c) < minp: minp=ord(c)
            if ord(c) > maxp: maxp=ord(c)
    for o,r,p in lefts:
        #print "    <", o, r
        #print "           ",p
        for pos in range(len(read)):
            EVO[pos].append(feat_of_left_ovlp(o, r, p, pos, read) + [float(o) / float(len(read))])


        for c in readphred:
            if ord(c) < minp: minp=ord(c)
            if ord(c) > maxp: maxp=ord(c)

    for o,r,p in rights:
        #print "    <", o, r
        #print "           ",p
        for pos in range(len(read)):
            EVO[pos].append(feats_of_right_ovlp(o, r, p, pos, read) + [float(o) / float(len(read))])

        for c in readphred:
            if ord(c) < minp: minp=ord(c)
            if ord(c) > maxp: maxp=ord(c)

    #print T[0],EVR[0],EVO[0]

    #print EVR[0] + norm_len(EVR[0][1:], EVO[0])
    for i in range(len(read)):
        #print EVR[i][0:1], T[i]
        alltargs.append([T[i]])
        featvec = [float(n) for n in reduce(lambda k,j: k + j, EVR[i][0:1] + norm_len(EVR[i][1:], EVO[i]))]
#        print len(featvec), len(EVR[0])
        allfeats.append(featvec)

print "writing vectors to file..."
v = open("vectors.csv", "w")
for feats,targ in itertools.izip(allfeats, alltargs):
    for feat in feats:
        v.write(str(feat) + ", ")
    v.write(str(targ) + "\n")
v.close()
    
allfeats = np.array(allfeats)
alltargs = np.array(alltargs)
print "feature dim", allfeats.ndim, "shape", allfeats.shape, "type", allfeats.dtype

def dopyml():
    mc = multi.OneAgainstRest (PyML.svm.SVM())
    scalars = [str(x[0]) for x in alltargs]
#alltargs = np.array(scalars)

    vds = PyML.containers.vectorDatasets.SparseDataSet(allfeats)
    vds.attachLabels(PyML.Labels(scalars))
    r = mc.cv(vds)
    print r

#for i in range(len(scalars)):
#     print allfeats[i,0:4], scalars[i]
#print "dim", alltargs.ndim, "shape", alltargs.shape, "type", alltargs.dtype




#print "alltargs.dim", alltargs.ndim

#, labelsColumn = -1)




print "len", len(allfeats), "inner len", len(allfeats[0])
# alltargs = np.zeros((len(allfeats),60))
print "min", min([min(x) for x in allfeats])
print "max", max([max(x) for x in allfeats])
# for i,feats in enumerate(allfeats):
#      for j, feat in enumerate(feats):
#          if feat == 0.0: print "found 0.0"



print "correctalready", already_correct 
print "initwrong", initially_wrong 


# for xy in range(10):
#     print alltargs[xy]



def donn():

    nnet = NeuralNetClassifier(55,(55,11),4)
    nnet.train(allfeats,alltargs,weightPrecision=1.e-8,errorPrecision=1.e-8,nIterations=100)
    print "SCG stopped after",nnet.getNumberOfIterations(),"iterations:",nnet.reason
    (classes,y,Z) = nnet.use(allfeats, allOutputs=True)
    print 'X(x1,x2), Target Classses, Predicted Classes'
    res = np.hstack((alltargs,classes))
    print res

# print res
# for x in res:
#     print x

#print "phredrange", minp,maxp

#dopyml()

