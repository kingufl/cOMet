import random

import sys
out = open(sys.argv[2],'w')


def emit(simval):
    #simval = random.gauss(simval, 150)
    if True:#simval >= 800: 
        out.write(str(float(simval)/1000.0) + " 0.150\n")

for line in open(sys.argv[1]):
    parts = [int(x) for x in line.strip().split(" ")]

pairs = zip([0] + parts, parts)

for x,y in pairs:
    simval = y - x
    #if simval < 800: continue
    emit(simval)

length = int(sys.argv[3])

emit(length - parts[-1])
