import Bio
import numpy as np
#%matplotlib inline
import matplotlib.pyplot as plt


import re
from Bio import SearchIO
from Bio import SeqIO
import Bio.SearchIO
import itertools
#import utils
import random
import subprocess 
import sys
import struct
import locale
import collections
locale.setlocale(locale.LC_ALL, 'en_US')

Alignment = collections.namedtuple('Alignment', ['locus', 'fval', 'chi_square_sum', 'deviation_sum', 'num_matched_frags', 'chi_square_cdf', 'forward', 'max_dev', 'fragnum'])
ConfigSet = collections.namedtuple("ConfigSet", 
                                   ['name', 'genome', 'dstdir', 'srcdir', 'ref_genome', 
                                    'assembly',
                                    'quast_ma', 'quast_local_ma',
                                    'sequel_ma', 
                                    'small_cutoff', 'stddev',
                                    'is_circular'])
def findall(s,q):
    hits = []
    h = s.find(q,0)
    while (h > 0 and h < len(s)):
        hits.append(h)
        h = s.find(q,h+1)
    return hits



def frags_of_offsets(offsets, length):
    """Return a generator for the sequence of fragments given a sequence of offsets (or positions) of cleavage sites and the length of a sequence."""
    return (y - x for x,y in zip(itertools.chain([0], offsets), itertools.chain(offsets, [length-1])))

# we want to eventually duplicate the list to deal with wrap-around alignments from the linearization of circular genomes
# we'll leave off the last part till after we add the noise

def partial_circ(lst):
    """Replace the last element with the sum of the first and last."""
    return lst[:-1] + [lst[0] + lst[-1]] 


# now add noise



def noise(lst,  SMALL_CUTOFF, STDDEV):
    return [int(random.gauss(0, STDDEV)) + s for s in lst if s >= SMALL_CUTOFF]


# and write these to disk

item = struct.Struct("i")

def writeit(fname, frags):
    
    om = open(fname, "wb")
    for frag in frags:
        om.write(item.pack(frag))
    om.close()

def len_from_contigname(name):
    return int(re.search(r"length_(\d+)_cov", name).group(1))

def within_ref_len(align):
    return  align < ref_len

def load_optmap(fname):
    """Return a list of the frags for a binary opt map file fname"""
    f = open(fname, "rb")
    frags = []
    word = f.read(4)
    
    while len(word) == 4:
        frag = item.unpack(word)
        frags.append(frag[0])
        word = f.read(4)
    print ("alphabet size is ", len(set(frags)))
    return frags

        
def bases_of_recseq(s):
    return s[0:s.find("'")] + s[s.find("'")+1:]

def enzyme_is_good(enz_name, enzymes):
    return len(getattr(Bio.Restriction, enz_name).site) >= 6

def load_silico(fname):
    digested_contigs = {}
    for lno, line in enumerate(open(fname)):
        if lno % 2 == 0:
            cn, l, num_fgs = line.strip().split()
        else:
            fgs = line.strip().split()
            digested_contigs[cn]= int(l), [int(f) for f in fgs]
    return digested_contigs



def make_optmap(enzyme_name, ref_fname, dst_fname, enzymes,   SMALL_CUTOFF, STDDEV, is_circular=False):
    # cell 1, get offsets
    handle = open(ref_fname, "rU")
    for record in SeqIO.parse(handle, "fasta"):
        matchrange = record.seq 
        
        #cut_offset = enzymes[enzyme_name].find("'")
        enz_offsets = [biosite - 1 for biosite in getattr(Bio.Restriction, enzyme_name).search(record.seq)]# [i + cut_offset for i in findall(matchrange, bases_of_recseq(enzymes[enzyme_name]))]
    
    # cell 2, do part of circle
    enz_frags = list(frags_of_offsets(enz_offsets, len(matchrange)))
    if is_circular:
        enz_frags = partial_circ(enz_frags)
    
    # cell 3, add noise
    noisy_enz_frags = noise(enz_frags,  SMALL_CUTOFF, STDDEV)
    #map_sizes[enzyme_name] = sum(noisy_enz_frags)
    
    # cell 4, finish circle
    if is_circular:
        noisy_enz_frags = noisy_enz_frags + noisy_enz_frags[1:]
    
    # cell 5, write it
    writeit(dst_fname, noisy_enz_frags)


def run_twin(enzyme_name, DSTDIR):
    localdict = {}
    #sa_aligns[enzyme_name] = {}
    cmd = "cd ~/class/research/fm/ "
    cmd += "&& ulimit -t 240 "
    cmd += "&& ./twin --fval 4 --max_chisquare_cdf 0.85 --opt_map "+DSTDIR+"enz_" + enzyme_name + ".om.bin "
    cmd += "--silico_map "+DSTDIR+"contigs." + enzyme_name + ".silico"
    
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
    lfname = DSTDIR+"twin_out." + enzyme_name
    matching_re = re.compile(r"^Matching contig ([^:]+):\(ignored (\d+)\) ((\d+ )+)\(ignored (\d+)\)")
    backward_re = re.compile(r"backward alignment:")
    alignment_pat_re = re.compile(r"Alignment pattern: ((\S+\t)+)")
    alignment_stats_re = re.compile(r"Alignment stats: (.*)")
    fin_string = "placed somewhere"
    found_end = False
    #logfile = open(lfname, "w")
    for line in proc.stdout:
        #if line[:len("        ")] == "        ": twinlog.write(line)
        #logfile.write(line)
        line = line.decode("utf-8")
        if line[:len(fin_string)] == fin_string: found_end = True

        mobj = alignment_stats_re.search(line)
        if mobj:
            astats = eval(mobj.group(1))
            #frag, safrag, locus, salocus, devscore, chiscore, varsum, matchedfrags = mobj.groups()

            #if not sa_aligns[enzyme_name].has_key(contig): sa_aligns[enzyme_name][contig]=[[],[]]    
            #astats['max_dev'] = max_dev
            astats['max_dev'] = 0
            astats['forward'] = forward
            a = Alignment(**astats)
#int(astats['locus']), float(astats['fval']), max_dev, float(astats['chi_square_sum']), int(astats['deviation_sum']), int(astats['num_matched_frags']), float(astats['chi_square_cdf']), forward)
            if astats['chi_square_cdf'] < .85:
                if not contig in localdict: localdict[contig]=[]
                localdict[contig].append(a)    
            #sa_aligns[enzyme_name][contig][forward].append(int(mobj.group(1)))         
            continue


        # mobj = alignment_pat_re.search(line)
        # if mobj:
        #     optfrags = [0 if part == "*" else int(part) for part in mobj.group(1).split("\t")[0:-1]]
        #     max_dev = max(( abs(optfrag - silicofrag) for optfrag, silicofrag in zip(optfrags, silicofrags if forward else reversed(silicofrags)) if silicofrag > 0))
            
            #print mobj.groups()


        mobj = matching_re.search(line)
        if mobj: 

            contig,leftignored,frags,_lastfrag,rightignored = mobj.groups()
            silicofrags = [int(part) for part in frags.split(" ")[0:-1]]
            forward = 0
            continue
        mobj = backward_re.search(line)
        if mobj:
            forward = 1
            continue
        # 
        # Aligned at optical frag (sa 152). Locus 4055514.
        #if re.search("Aligned at optical frag", line): print line


        
        #mobj = re.search(r"Aligned at optical frag: (\d+)\(sa (\d+)\)\. Locus: (\d+)\(sa (\d+)\). Fval: (\d+\.\d+)\. Chi Squared sum: (\d+\.\d+)\. Deviation sum: (\d+)\. Matched frags: (\d)\.", line)

    
    numaligns = 0
    if found_end:
        return localdict
    else:
        return {}
    for contig, align_lists in localdict.items():
        numaligns += len(align_lists[0]) + len(align_lists[1])
    #print(numaligns)
    if numaligns < 1000000:
        aligns[enzyme_name] = localdict
    

def comp(x):
    if x == 'A': return 'T'
    if x == 'G': return 'C'
    if x == 'T': return 'A'
    if x == 'C': return 'G'
    if x == "'": return "'"
    if x == "^": return "^"
    if x == "_": return "_"



def load_enzymes(fname):
    enzymes = {}
    for line in open(fname):
        mobj = re.search(r"^(\w+)/([AGCT']+)/", line)
        if mobj:
            enzymes[mobj.group(1)] = mobj.group(2)
    return enzymes

def soft_digest_contigs(enzyme_name, contig_iterable):
    localdict = {}
    for record in contig_iterable:
        sites = [biosite - 1 for biosite in getattr(Bio.Restriction, enzyme_name).search(record.seq)]
        #sites = [m.start() + int(cut_offset) for m in re.finditer(recognition_sequence, str(record.seq))]
        localdict[record.id] = sites
    return localdict    

def soft_digest(enzyme_name, fasta_file):
    return soft_digest_contigs(enzyme_name, SeqIO.parse(open(fasta_file, "rU"), "fasta"))





def run_digest(enzyme_name, fasta_file, DSTDIR):
    out_fname = DSTDIR+"contigs." + enzyme_name + ".silico"
    out_h = open(out_fname, "w")

    for record in SeqIO.parse(open(fasta_file, "rU"), "fasta"):
        sites = [biosite - 1 for biosite in getattr(Bio.Restriction, enzyme_name).search(record.seq)]
        #sites = [m.start() + int(cut_offset) for m in re.finditer(recognition_sequence, str(record.seq))]
        if len(sites) > 1: 
            out_h.write(str(record.id) + " " + str(len(record.seq)) + " " + str(len(sites)) + "\n")
            out_h.write(" ".join((str(s) for s in sites)) + " \n")

    out_h.close()

    
def distinct_enzymes():
    """ return a dict of enz_name to rec_seq where each rec_seq only occurs once in the dict (i.e. no neoschizomers or isoschizomres)"""
    recseqs = {}
    for enz in Bio.Restriction.AllEnzymes:
        if enz not in recseqs: recseqs[enz.site] = []
        recseqs[enz.site].append(enz.__name__)
    retdict = {}
    for recseq,enzs in recseqs.items():
        retdict[enzs[0]] = recseq
    return retdict

def f1(tp, fp, fn):
    return 2 * float(tp) / (2 * float(tp) + fp + fn)
