print "loading file..."
execfile("mldata1000.py")
import sys
import numpy as np
import itertools
import random
from neuralnetworksMulti import *
import math
import PyML
from PyML.classifiers import multi

minp,maxp = 256,0

def prob_of_phred(phred):
    phred = phred - 33
    return 1.0 - 10**(phred*-.1)

def rephred(n):
    return n #-10 * math.log(n,10)

classmap = { 'A' : 1,
             'C' : 2,
             'G' : 3,
             'T' : 4 }

def feats_of_base(base, phred):
    phredprob = prob_of_phred(ord(phred))
    rest = rephred((1.0 - phredprob) / 3.0)
    feats = [ rest, rest, rest, rest]
    feats[classmap[base]-1] = rephred(phredprob)
    return feats


def mapped_left_ovlp(o, r, p, readpos, actualread):
    nonovlp = len(r) - o
    if readpos < o:
        mappos = readpos+nonovlp - 0
        return mappos
    else:
        return -1

def feat_of_left_ovlp(o, r, p, readpos, actualread):
    nonovlp = len(r) - o
    if readpos < o:
        mappos = readpos+nonovlp - 0
        return feats_of_base(r[mappos], p[mappos])
    else:
        return [rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0)]

def norm_len(evr, evo):
    """given lists of read and other features, produce a list of length 10 with items permuted"""
    newlist = evr + evo
    if len( newlist) <= 10:
        for i in range(10 - len(newlist) + 1):
            newlist.append([rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0), 1.0])
    if len(newlist) > 10: 
        newlist = newlist[0:9]
    random.shuffle(newlist)
    #print newlist
#    print len(newlist)
    return newlist

def mapped_right_ovlp(o,r,p,readpos,actualread):
    nonovlp = len(actualread) - o
    if readpos < nonovlp:
        return -1
    else:
        mappos = readpos - nonovlp 
        return mappos

def feats_of_right_ovlp(o,r,p,readpos,actualread):
    nonovlp = len(actualread) - o
    if readpos < nonovlp:
        return [rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0), rephred(1.0/4.0)]
    else:
        mappos = readpos - nonovlp 
        return feats_of_base(r[mappos], p[mappos])

comp = { 'A' : 'T', 'T':'A', 'G':'C', 'C':'G'}

def revcomp(s):
    return list(reversed("".join( (comp[x] for x in s))))

print "generating features..."    
allfeats = []
alltargs = []
readcount = 0
already_correct =0
initially_wrong = 0
for ref,read,readphreds,lefts,rights in mldata:
    readcount +=1
    #if readcount > 3: break
    T = []
    EVR = [] #evidence from read itself
    EVO = [] # evidence from others

    #print "******** read data set ************"
    #print ref
    for i,base in enumerate(ref):
        pass #sys.stdout.write(base)
        
        T.append(classmap[base])
        if readcount > 50000/100:
            if base == read[i]:
                already_correct += 1
            else:
                initially_wrong += 1
    #print 
    #print " # reference"





    
    # create the positions for the features for each example
    for i in read:
        pass #sys.stdout.write(i)
        EVR.append([])
        EVO.append([])
    #print " # read"



    
    
    for readphred in readphreds:
        #print readphred, "# read phred"
        for pos, (r,p) in enumerate(itertools.izip(read, readphred)):
            EVR[pos].append( feats_of_base(r,p) + [1.0])
            
        #print "    ", readphred
        for c in readphred:
            if ord(c) < minp: minp=ord(c)
            if ord(c) > maxp: maxp=ord(c)

                
    for o,r,p, sense in lefts:
        #print "    <", o, r
        #print "           ",p
        rcomp = revcomp(r)
        prev = "".join(list(reversed(p)))
            
        
        if sense == 1:

            for pos in range(len(read)):
                mapped = mapped_left_ovlp(o, r, p, pos, read)
                EVO[pos].append(feat_of_left_ovlp(o, rcomp, prev, pos, read) + [float(o) / float(len(read))])
                if mapped < 0:  pass #sys.stdout.write("_")
                else: pass #sys.stdout.write(rcomp[mapped])
            #print " # left overlap revcomp"
        else:
            for pos in range(len(read)):
                EVO[pos].append(feat_of_left_ovlp(o, r, p, pos, read) + [float(o) / float(len(read))])
                mapped = mapped_left_ovlp(o, r, p, pos, read)
                if mapped < 0:  pass #sys.stdout.write("_")
                else: pass #sys.stdout.write(r[mapped])

            #print " # left overlap"


        for c in readphred:
            if ord(c) < minp: minp=ord(c)
            if ord(c) > maxp: maxp=ord(c)

    for o,r,p, sense in rights:
        #print "    <", o, r
        #print "           ",p
        rcomp = revcomp(r)
        prev = "".join(list(reversed(p)))

        if sense == 2:
            for pos in range(len(read)):
                EVO[pos].append(feats_of_right_ovlp(o, rcomp, prev, pos, read) + [float(o) / float(len(read))])
                mapped = mapped_right_ovlp(o, r, p, pos, read)
                if mapped < 0: pass #sys.stdout.write("_")
                else: pass #sys.stdout.write(rcomp[mapped])
            #print " # right overlap revcomp"
        else:
            for pos in range(len(read)):
                EVO[pos].append(feats_of_right_ovlp(o, r, p, pos, read) + [float(o) / float(len(read))])
                mapped = mapped_right_ovlp(o, r, p, pos, read)
                if mapped < 0: pass #sys.stdout.write("_")
                else: pass #sys.stdout.write(r[mapped])
            #print " # right overlap"


        for c in readphred:
            if ord(c) < minp: minp=ord(c)
            if ord(c) > maxp: maxp=ord(c)

    #print T[0],EVR[0],EVO[0]

    #print EVR[0] + norm_len(EVR[0][1:], EVO[0])
    for i in range(len(read)):
        #print EVR[i][0:1], T[i]
        alltargs.append([T[i]])
        overlapping_reads = norm_len(EVR[i][1:], EVO[i])

        featvec = [float(n) for n in reduce(lambda k,j: k + j, EVR[i][0:1] + overlapping_reads)]
        featvec = featvec[0:4] + featvec[5:]

 #       print len(featvec), len(EVR[0])
#        print len(featvec)
        allfeats.append(featvec)

allfeats = np.array(allfeats)
alltargs = np.array(alltargs)
print "features dim", allfeats.ndim, "shape", allfeats.shape, "type", allfeats.dtype
print "targets dim", alltargs.ndim, "shape", alltargs.shape, "type", alltargs.dtype


def dopyml():
    #mc = multi.OneAgainstRest (PyML.svm.SVM(PyML.ker.Gaussian()))
    mc = multi.OneAgainstRest (PyML.svm.SVM(optimizer = 'liblinear'))
    scalars = [str(x[0]) for x in alltargs]
#alltargs = np.array(scalars)
    halfscalars = scalars[0:len(scalars)/2]
    sndhalfscalars = scalars[len(scalars)/2:]
    vds = PyML.containers.vectorDatasets.SparseDataSet(half)
    vds.attachLabels(PyML.Labels(halfscalars))
    mc.train(vds)
    sndvds = PyML.containers.vectorDatasets.SparseDataSet(sndhalf)
    sndvds.attachLabels(PyML.Labels(sndhalfscalars))
    res = mc.test(sndvds)
    pairs = zip(sndhalfscalars,res)
    print pairs
    errs=  sum(x[0] == x[1] for x in pairs)
    allof = len(res)
    print "pyml success rate", errs, "/", allof, "=", errs/float(allof)

    print r

#for i in range(len(scalars)):
#     print allfeats[i,0:4], scalars[i]
#print "dim", alltargs.ndim, "shape", alltargs.shape, "type", alltargs.dtype




#print "alltargs.dim", alltargs.ndim

#, labelsColumn = -1)




print "len", len(allfeats), "inner len", len(allfeats[0])
# alltargs = np.zeros((len(allfeats),60))
print "min", min([min(x) for x in allfeats])
print "max", max([max(x) for x in allfeats])
# for i,feats in enumerate(allfeats):
#      for j, feat in enumerate(feats):
#          if feat == 0.0: print "found 0.0"



print "correctalready", already_correct 
print "initwrong", initially_wrong 
print "initial rate", float(already_correct )/ (already_correct + initially_wrong)

# for xy in range(10):
#     print alltargs[xy]

        
half = allfeats[0:allfeats.shape[0]/2,:]
sndhalf = allfeats[allfeats.shape[0]/2:,:]

halftargs = alltargs[0:alltargs.shape[0]/2,:]
sndhalftargs = alltargs[alltargs.shape[0]/2:,:]

print "shapes", half.shape,sndhalf.shape,halftargs.shape,sndhalftargs.shape
def donn():

    nnet = NeuralNetClassifier(49,(49,10 ),4)
    nnet.train(half,halftargs,weightPrecision=1.e-8,errorPrecision=1.e-8,nIterations=2000)
    print "SCG stopped after",nnet.getNumberOfIterations(),"iterations:",nnet.reason
    (classes,y,Z) = nnet.use(sndhalf, allOutputs=True)
    print 'X(x1,x2), Target Classses, Predicted Classes'
    res = np.hstack((sndhalftargs,classes))
    errs=  sum(x[0] == x[1] for x in res)
    allof = len(res)
    print "NN success rate", errs, "/", allof, "=", errs/float(allof)
    print res

# print res
# for x in res:
#     print x

#print "phredrange", minp,maxp
donn()
#dopyml()


