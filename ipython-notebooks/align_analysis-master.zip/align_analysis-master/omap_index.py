import sys
tot = 0

for line in open(sys.argv[1]):
    parts = line.split(" ")
    size = float(parts[0])*1000
    size = int(size)
    print tot,line,
    tot+=size
    
